<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */
    global $redux_demo;
?>
<footer>
		<div class="container">
			<div class="col-md-3 col-sm-3">
				<h3>ONLINE SHOPPING</h3>
				<?php wp_nav_menu(array('menu'=>'ONLINE-SHOPPING','menu_class'=>''));?>
			</div>
			<div class="col-md-3 col-sm-3">
				<h3>USEFUL LINKS</h3>
					<?php wp_nav_menu(array('menu'=>'USEFULL-LINKS','menu_class'=>''));?>
			</div>
			<div class="col-md-3 col-sm-3">
			<?php dynamic_sidebar("sidebar-4");?>
			</div>
			<div class="col-md-3 col-sm-3">
<?php dynamic_sidebar("sidebar-5");?>
			</div>
			<div class="copy-right">
				<p><img src="<?php echo $redux_demo['opt-secure-logo']['url'];?>"><?php echo $redux_demo['opt-footer-copyright'];?></p>
			</div>
		</div>
			
	</footer>
	<script>

var timer = {
        started: false,
        timestamp: 0
    },
    trigger = 15;                          //3pm

function timerInit(){
    var hour = new Date().getHours();
    if(!timer.started && hour === trigger){      //When it's 3pm, the timer will start
        startTimer();                      //└─ rewrite the conditional statement 
                                           //   as needed
        //do whatever you want here
        timer.timestamp = +new Date();
        timer.started = true;              //Indicates the timer has been started
    }
    requestAnimationFrame(timerInit);      //setTimeout is not efficient
}
//requestAnimationFrame(timerInit);


//This is for when the timer has ended.
function timerEnded(){
    timer.started = false;
}

function startTimer(){
    var d = new Date();
    timePassed = +new Date(timer.timestamp + 1000*60*60*6 - d);
//console.log(timePassed);
	var str = getcountdownnum(timePassed/1000);
	//str =	timePassed.toString();
    //str += '<br>0 days '+remaining.hour+' hours '+remaining.minute+' minutes '+remaining.second+' seconds';
	if(document.getElementById('timer')){
		document.getElementById('timer').innerHTML = str;
	}
    //console.log(remaining);
    if(timePassed > 0){
        setTimeout(startTimer, 500);       //Countdown
    }else{
        timerEnded();                      //Ended
    }
}

window.onload=function(){
     timer.started=true;
    timer.timestamp=+new Date();
    startTimer();   
}

function getcountdownnum(num){
	var txt=num
	txt=Number(txt)
	var day=0
	var hour=0
	var min=0
	var sec=0
	for(i=0;i>-1;i++){
		if(txt>=86400){
			txt-=86400
			day++
		}else{
			break
		}
	}
	for(i=0;i>-1;i++){
		if(txt>=3600){
			txt-=3600
			hour++
		}else{
			break
		}
	}
	for(i=0;i>-1;i++){
		if(txt>=60){
			txt-=60
			min++
		}else{
			break
		}
	}
	sec=txt
	if(sec==60){
		sec=0
	}
	var final=""
	if(day!=0){
		final=day+((day==1)?" day ":" days ")
	}
	if(hour<10){
		hour="0"+hour
	}
	if(min<10){
		min="0"+min
	}
	if(sec<10){
		sec="0"+sec
	}

    final=final+'<li>'+hour+"</li>:<li>"+min+"</li>:<li>"+Math.round(sec)+'</li>';
	return final
}


</script>
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
	<!-- Include all compiled plugins (below), or include individual files as needed -->
	<script src="<?php echo get_template_directory_uri();?>/js/bootstrap.min.js"></script>
	<script src="<?php echo get_template_directory_uri();?>/js/jquery.min.js"></script>
    <script src="<?php echo get_template_directory_uri();?>/js/owl.carousel.js"></script>
	<script>
	jQuery(document).ready(function() {
		
		$("h2.woocommerce-loop-product__title").text(function(index, currentText) {
			//console.log(currentText.substr(0, 10));
		//	currentText.length();
			if(currentText.length >= 30){
			  $(this).text(currentText.substr(0, 30)+'...');
			}else{
				
				 $(this).text(currentText.substr(0, 30));
			}
	});
	
			$("h3.wooTitle").text(function(index, currentText) {
		if(currentText.length >= 30){
			  $(this).text(currentText.substr(0, 30)+'...');
			}else{
				
				 $(this).text(currentText.substr(0, 30));
			}
		});	
		$("h4.wooTitle").text(function(index, currentText) {
		if(currentText.length >= 35){
			  $(this).text(currentText.substr(0, 35)+'...');
			}else{
				
				 $(this).text(currentText.substr(0, 35));
			}
	});
		  //email validation
      $( ".wholeSaleForm" ).submit(function( event ) {
		  

		 
		 
        var business_name = $("input[name='business_name']").val();
        var address_line = $("input[name='address_line']").val();
        var city_town = $("input[name='city_town']").val();
        var state_region = $("input[name='state_region']").val();
        var business_country_name = $("input[name='business_country_name']").val();
        var zip_code = $("input[name='zip_code']").val();
        var sale_first_name = $("input[name='sale_first_name']").val();
        var sale_last_name = $("input[name='sale_last_name']").val();
        var sale_phone_number = $("input[name='sale_phone_number']").val();
        var email_address = $("input[name='email_address']").val();
        var account_first_name = $("input[name='account_first_name']").val();
        var account_last_name = $("input[name='account_last_name']").val();
        var account_phone_number = $("input[name='account_phone_number']").val();
        var account_email_address = $("input[name='account_email_address']").val();
        var account_address = $("input[name='account_address']").val();
        var account_city_town = $("input[name='account_city_town']").val();
        var account_state_region = $("input[name='account_state_region']").val();
        var account_zip_code = $("input[name='account_zip_code']").val();
        var channel_number = $("input[name='channel_number']").val();
        var ein_number = $("input[name='ein_number']").val();


		  
				if(sale_first_name.trim() == ""){
				alert("Please Fill The Remaining Fields!");
				return false;

				} 
			if(sale_last_name.trim() == ""){
			alert("Please Fill The Remaining Fields!");
			return false;
			} 
			if(account_first_name.trim() == ""){
			alert("Please Fill The Remaining Fields!");
			return false;
			} 
			if(account_last_name.trim() == ""){
			alert("Please Fill The Remaining Fields!");
			return false;
			} 			

		
        if(business_name.trim() == "" || address_line.trim() == "" || city_town.trim() == "" || state_region.trim() == "" || business_country_name.trim() == "" || zip_code.trim() == "" || sale_first_name.trim() == "" || sale_last_name.trim() == "" || sale_phone_number.trim() == "" || email_address.trim() == "" || account_first_name.trim() == "" || account_last_name.trim() == "" || account_phone_number.trim() == "" || account_email_address.trim() == "" || account_address.trim() == "" || account_city_town.trim() == "" || account_state_region.trim() == "" || account_zip_code.trim() == "" || channel_number.trim() == ""  || ein_number.trim() == ""){
        alert("Please Fill The Remaining Fields!");
          return false;
        }
		

        var emailShipping = $('form .email_address').val();
        var filterEmail = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
        if (filterEmail.test(emailShipping)) {
           $(".invalidEmail").text('');
        }
        else{
          event.preventDefault();
          $(".invalidEmail").text('Please enter a valid email address.');
          return false;
        }
		
		var account_email_address = $('form .account_email_address').val();
        var filterEmail = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
        if (filterEmail.test(account_email_address)) {
           $(".invalidEmail").text('');
        }
        else{
          event.preventDefault();
          $(".invalidEmail2").text('Please enter a valid email address.');
          return false;
        }

      });
		
		
	//	$("#mega-toggle-block-1").trigger("click");
		$('.mobileSrchICon').click(function(){
			$(".mobileSrch").toggleClass("displaySrch");
		});
	$('.closeSrch').click(function(){
			$(".mobileSrch").removeClass("displaySrch");
		});
		

			if ( $(window).width() < 768 ) {
							$('#deail-silder6').addClass('owl-carousel owl-theme');
			$('#deail-silder6').owlCarousel({
				 stagePadding: 50,
				  loop:true,
				margin:5,
				nav: true,
				responsive: {
				  0: {
					items: 1
				  },
				  549: {
					items:2 
				  },
				  767: {
					items:2
				  }
				}
			  });
			  
			  
			  
		$('#deail-silder7').addClass('owl-carousel owl-theme');
			$('#deail-silder7').owlCarousel({
				margin:5,
				nav: true,
				responsive: {
				  0: {
					items: 1
				  },
				  549: {
					items:2 
				  },
				  767: {
					items:2
				  }
				}
			  });
  
			 $('#cata-slide').addClass('owl-carousel owl-theme');
			$('#cata-slide').owlCarousel({
				stagePadding:15,
				margin:5,
				  loop:false,
				nav: false,
				dots:false,
				responsive: {
				  0: {
					items:2
				  },
				  549: {
					items:3
				  },
				  767: {
					items:3
				  }
				}
			  });	
			$('#cateogory-silder').addClass('owl-carousel owl-theme');
				$('#cateogory-silder').owlCarousel({
					stagePadding:15,
				margin:5,
				  loop:false,
				nav: false,
				dots:false,
					responsive: {
					  0: {
						items:2
					  },
					  549: {
						items:3
					  },
					  767: {
						items:3
					  }
					}
				  });
				 $('#cata-mobile').addClass('owl-carousel owl-theme');
				$('#cata-mobile').owlCarousel({
					stagePadding:15,
					margin:5,
					loop:false,
					nav: false,
					dots:false,
					responsive: {
					  0: {
						items: 1
					  },
					  549: {
						items:3
					  },
					  767: {
						items:3
					  }
					}
				  });	
				  $('#collect-silder').addClass('owl-carousel owl-theme');
				$('#collect-silder').owlCarousel({
					stagePadding:15,
					margin:5,
					loop:false,
					nav: false,
					dots:false,
					responsive: {
					  0: {
						items: 1
					  },
					  549: {
						items:3
					  },
					  767: {
						items:3
					  }
					}
				  });	

				  $('#arrivals-silder').addClass('owl-carousel owl-theme');
				$('#arrivals-silder').owlCarousel({
					stagePadding:15,
					margin:5,
					loop:false,
					nav: false,
					dots:false,
					responsive: {
					  0: {
						items:1
					  },
					  549: {
						items:3
					  },
					  767: {
						items:3
					  }
					}
				  });		
			$('#deail-silder').addClass('owl-carousel owl-theme');
			$('#deail-silder').owlCarousel({
				stagePadding:15,
				margin:5,
				nav: true,
				loop:true,
				responsive: {
				  0: {
					items: 2
				  },
				  480: {
					items:2 
				  },
				  767: {
					items: 3
				  },
				   1320: {
					items: 4
				  }
				}
			  });				  
			}else{
						$('#deail-silder').addClass('owl-carousel owl-theme');
			$('#deail-silder').owlCarousel({
				margin:20,
				nav: true,
				loop:true,
				responsive: {
				  0: {
					items: 2
				  },
				  480: {
					items:2 
				  },
				  767: {
					items: 3
				  },
				   1320: {
					items: 4
				  }
				}
			  });
			}
			
			console.log($(window).width());	
		if ( $(window).width() < 1200 ) {
console.log("sdfsd");			
			$('#deail-silder2').addClass('owl-carousel owl-theme');
			$('#deail-silder2').owlCarousel({
				 	stagePadding:15,
					margin:5,
					loop:false,
					nav: false,
					dots:false,
				responsive: {
				  0: {
					items: 2
				  },
				  480: {
					items:2 
				  },
				  767: {
					items:3
				  },
				  992: {
					items:4
				  }
				}
			  });
			  
			  			$('#deail-silder3').addClass('owl-carousel owl-theme');
			$('#deail-silder3').owlCarousel({
				 stagePadding:15,
				 margin:5,
					loop:false,
					nav: false,
					dots:false,
				responsive: {
				  0: {
					items: 2
				  },
				  480: {
					items:2 
				  },
				   767: {
					items:3
				  },
				  992: {
					items:4
				  }
				}
			  });
			  
			 $('#deail-silder4').addClass('owl-carousel owl-theme');
			$('#deail-silder4').owlCarousel({
					stagePadding:15,
					margin:5,
					loop:false,
					nav: false,
					dots:false,
				responsive: {
				  0: {
					items: 2
				  },
				  480: {
					items:2 
				  },
				  767: {
					items:3
				  },
				  992: {
					items:4
				  }
				}
			  });
			  $('#deail-silder5').addClass('owl-carousel owl-theme');
			$('#deail-silder5').owlCarousel({
					stagePadding:15,
					margin:5,
					loop:false,
					nav: false,
					dots:false,
				responsive: {
				  0: {
					items: 2
				  },
				  480: {
					items:2 
				  },
				  767: {
					items:3
				  },
				  992: {
					items:4
				  }
				}
			  });
			} 

	});
	</script>
	<script src='https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.js'></script>
	<script>
	$('.slider-main').slick({
  slidesToShow: 1,
  arrows: false,
  asNavFor: '.slider-nav',
  vertical: false,
  autoplay: false,
  verticalSwiping: false,
  centerMode: false,
  dots:true
});

$('.slider-nav').slick({
  slidesToShow: 5,
  asNavFor: '.slider-main',
  vertical: true,
  focusOnSelect: true,
  autoplay: false,
  centerMode: false
});

/* $(window).on('resize orientationchange', function() {
  if ($(window).width() > 1200) {
    $('.slider-nav').slick('unslick');
    $('.slider-nav').slick({
      slidesToShow: 4,
      asNavFor: '.slider-main',
      vertical: true,
      focusOnSelect: true,
      autoplay: false,
      centerMode: true
    });
  }
}); */
	</script>
	
		<script>	
		<!-----------Image change code ----------------->
			jQuery( document ).ready( function(){
				
				
				jQuery('.reset_variations').click(function(){
						 $(".showVarint").hide();
					 $(".hidevarint").show();
					
				});
				
		jQuery('.image-variable-item').click(function(){
			var variation_id = 	jQuery(".variation_id").val();
			var colorVal = $(this).attr("data-value");
			var aVal = 1;
			var sizeVal = jQuery('.button-variable-item.selected').attr("data-value");
//console.log(colorVal);
			//console.log(sizeVal);
			if(typeof(sizeVal) != "undefined"){
				
				setTimeout(function(){
				//	console.log(jQuery('.getVarients-'+colorVal+'-'+sizeVal).attr("data-img"));
					jQuery('.slick-current.slick-active img').attr("src",jQuery('.getVarients-'+colorVal+'-'+sizeVal).attr("data-img"));
					jQuery(".variableCart").attr("href","<?php echo site_url();?>/checkout/?add-to-cart="+variation_id);
					jQuery(".vrntPrice").text(jQuery('.getVarients-'+colorVal+'-'+sizeVal).attr("data-varientsprice"));
					
					 $(".showVarint").show();
					 $(".hidevarint").hide();
					
					
					
					
					},
				500);
			}else{
				if(typeof(jQuery('.getVarients-'+colorVal).attr("data-varientsprice")) != "undefined"){
					jQuery(".vrntPrice").text(jQuery('.getVarients-'+colorVal).attr("data-varientsprice"));
					 $(".showVarint").show();
					 $(".hidevarint").hide();
				}
				jQuery('.slick-current.slick-active img').attr("src",jQuery('.getVarients-'+colorVal).attr("data-img"));
				jQuery(".variableCart").attr("href","<?php echo site_url();?>/checkout/?add-to-cart="+variation_id);
				
			}

		});
		jQuery('.button-variable-item').click(function(){
			var variation_id = 	jQuery(".variation_id").val();
			var sizeVal = $(this).attr("data-value");
			var aVal = 1;
			var colorVal = jQuery('.image-variable-item.selected').attr("data-value");
			console.log(colorVal);
			console.log(sizeVal);
			if(typeof(colorVal) != "undefined"){
				
				setTimeout(function(){
					console.log(jQuery('.getVarients-'+colorVal+'-'+sizeVal).attr("data-img"));
					jQuery('.slick-current.slick-active img').attr("src",jQuery('.getVarients-'+colorVal+'-'+sizeVal).attr("data-img"));
					jQuery(".variableCart").attr("href","<?php echo site_url();?>/checkout/?add-to-cart="+variation_id);
					jQuery(".vrntPrice").text(jQuery('.getVarients-'+colorVal+'-'+sizeVal).attr("data-varientsprice"));
					 $(".showVarint").show();
					 $(".hidevarint").hide();
					},
				500);
			}else{
				if(typeof(jQuery('.getVarients-'+sizeVal).attr("data-varientsprice")) != "undefined"){
					jQuery(".vrntPrice").text(jQuery('.getVarients-'+sizeVal).attr("data-varientsprice"));
					 $(".showVarint").show();
					 $(".hidevarint").hide();
				}
						jQuery('.slick-current.slick-active img').attr("src",jQuery('.getVarients-'+sizeVal).attr("data-img"));
						jQuery(".variableCart").attr("href","<?php echo site_url();?>/checkout/?add-to-cart="+variation_id);
			}

		});
				
		jQuery('.productCart').click(function(){
			jQuery(".single_add_to_cart_button").trigger("click");
		}); 
		
		jQuery('.variableCart').click(function(){
			var variation_id = 	jQuery(".variation_id").val();
			if (variation_id){
				jQuery(".variableCart").attr("href","<?php echo site_url();?>/checkout/?add-to-cart="+variation_id);
			}else{
				jQuery(".single_add_to_cart_button").trigger("click");
			}
		}); 
		
		});
			</script>
			
			
	<?php wp_footer();?>
	<script>
	jQuery( document ).ready( function( $ ){
$(document).on( 'added_to_wishlist removed_from_wishlist', function(){
var counter = $('.your-counter-selector');

$.ajax({
url: yith_wcwl_l10n.ajax_url,
data: {
action: 'yith_wcwl_update_wishlist_count'
},
dataType: 'json',
success: function( data ){
counter.html( data.count );
},
beforeSend: function(){
//counter.block();
},
complete: function(){
//counter.unblock();
}
})
} )
});
</script>
<script>
jQuery(document).ready(function(){
	
	jQuery(".main-expand").addClass("active");
	jQuery(".expand:not(:first)").hide();

	jQuery(".main-expand").click(function(){
		$(this).next(".expand").slideToggle("slow")
		.siblings(".expand:visible").slideUp("slow");
		$(this).toggleClass("active");
		$(this).siblings(".main-expand").removeClass("active");
	});

  $(document).mouseup(function(e) 
                      {
    var container = jQuery("#bs-example-navbar-collapse-1");
    // if the target of the click isn't the container nor a descendant of the container
    if (!container.is(e.target) && container.has(e.target).length === 0) 
    {
		
		if($("#bs-example-navbar-collapse-1").hasClass( "in" )){
			$(".topNavToggle").trigger("click");
    }
	}
  });
  
  
  //Sort by 
  
	var repalceText = $(this).find(".orderby-item.active").html();
		var sortText = repalceText.replace("Sort by", "");
  
  $(".activeSort").html(sortText);
  
  	$(document).on("click",".orderby-wrapper", function(){
		
		console.log($(this).find(".orderby-item").html());
		var repalceText = $(this).find(".orderby-item").html();
		var sortText = repalceText.replace("Sort by", "");
		
		$(".activeSort").html(sortText);
	});

});



var activeSort = $(".activeSort").html();
var orderby = $(".orderby-item.active").html();

if(activeSort.trim() == orderby.trim()){
	
	setTimeout(function(){ 
	
	
	}, 4000);
}
	</script>

<script>

$(document).ready(function(){
	$(".filter-sec-btn button").click(function(){
		$(".searchFilters").toggleClass('open-filter');
		$("body").toggleClass('filterClass');
		
		$(".btnClose").toggleClass('btcCloseActive');
		$(".sort-sec-btn").toggleClass('sortClose');
		
	});
		$(".btnClose").click(function(){
		$("body").toggleClass('filterClass');
		$(".searchFilters").toggleClass('open-filter');
		$(".btnClose").removeClass('btcCloseActive');
		$(".sort-sec-btn").removeClass('sortClose');
		
	});
	
  
	$(".sort-sec-btn button").click(function(){
		$(".overlay-div").addClass('open-sort');
	});
	
	$(".overlay-div").click(function(){
		$(".overlay-div").removeClass('open-sort');
	})
	
 		$(".tabHide").click(function(){
			$(".searchFilters").removeClass("open-filter");
			
	});
	
/*	$(".filterBtn").click(function(){
			$(".open-filter").slideDown();
			$(".searchFilters").hide();
			console.log("asdas");
	}); */
	
	
	
	$(".tabHide,.orderby-item").click(function() {
		$("body").toggleClass('filterClass');
		$(".sort-sec-btn").removeClass('sortClose');
			if($(".btnClose").hasClass('btcCloseActive')){
			$(".btnClose").removeClass('btcCloseActive');
		}
    $('html, body').animate({
		
	
		
        scrollTop: $("#arrivals-silder").offset().top
    }, 2000);
});
	
	
	    $(".sortByDiv").on("mouseenter", function() {
       $("#yith-woo-ajax-navigation-sort-by-2").show();
            $("#yith-woo-ajax-navigation-sort-by-2").addClass("hideUlli");
	   
    });
    $(".sortByDiv").on("mouseleave", function() {
       $("#yith-woo-ajax-navigation-sort-by-2").hide();
	        $("#yith-woo-ajax-navigation-sort-by-2").removeClass("hideUlli");
    });
	
});


</script>
  </body>
</html>