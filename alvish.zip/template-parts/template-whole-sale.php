<?php

/*
Template Name: template-whole-sale
 */
 
 get_header();
  global $redux_demo;
  
global $wpdb;
if ( isset( $_POST['submit'] ) ){
	
  $tablename=$wpdb->prefix.'whole_sale_orders';
 
$uploaddir = wp_upload_dir();
 $file = $_FILES['fileUpload' ];

require_once( ABSPATH . 'wp-admin/includes/image.php' );
require_once( ABSPATH . 'wp-admin/includes/file.php' );
require_once( ABSPATH . 'wp-admin/includes/media.php' );
 $uploadfile = $uploaddir['path'] . '/' . basename( $file['name'] );

move_uploaded_file( $file['tmp_name'] , $uploadfile );
$filename = basename( $uploadfile );
$wp_filetype = wp_check_filetype(basename($filename), null );
$attachment = array(
	'post_mime_type' => $wp_filetype['type'],
	'post_title' => preg_replace('/\.[^.]+$/', '', $filename),
	'post_content' => '',
	'post_status' => 'inherit'
	);
 $attach_id = wp_insert_attachment( $attachment, $uploadfile );


 		$in = $wpdb->query("INSERT INTO `$tablename`(`business_name`, `address_line`, `address_line2`, `city_town`,`state_region`, `business_country_name`, `zip_code`, `sale_first_name`, `sale_last_name`, `sale_phone_number`, `email_address`, `account_first_name`, `account_last_name`, `account_phone_number`, `account_email_address`, `account_address`, `account_address2`, `account_city_town`, `account_state_region`, `account_country_name`, `account_zip_code`, `channel_number`, `ein_number`, `channel_myfile`) VALUES ('".$_POST["business_name"]."','".$_POST["address_line"]."','".$_POST["address_line2"]."','".$_POST["city_town"]."','".$_POST["state_region"]."','".$_POST["business_country_name"]."','".$_POST["zip_code"]."','".$_POST["sale_first_name"]."','".$_POST["sale_last_name"]."','".$_POST["sale_phone_number"]."','".$_POST["email_address"]."','".$_POST["account_first_name"]."','".$_POST["account_last_name"]."','".$_POST["account_phone_number"]."','".$_POST["account_email_address"]."','".$_POST["account_address"]."','".$_POST["account_address2"]."','".$_POST["account_city_town"]."','".$_POST["account_state_region"]."','".$_POST["account_country_name"]."','".$_POST["account_zip_code"]."','".$_POST["channel_number"]."','".$_POST["ein_number"]."','".$attach_id."')");
		  $pdf =  wp_get_attachment_url( $attach_id );
		
		$data = $pdf;   
		
		   $pdf = str_replace(get_site_url(),"",$data);
		

//echo $whatIWant;

		if($in){
			
			
			
		
						$to = 'test.suffescom@gmail.com';

					$subject = 'Wholesale Orders';

					$headers = 'From: <whole@alvish.com>' . "\r\n";
					//$headers = 'From: <survey@MoreNaturalHealing.com>' . "\r\n";
					
					$headers .= "MIME-Version: 1.0\r\n";
					$headers .= "Content-Type: text/html; charset=UTF-8\r\n";
$message = '<html>
			<head>
			<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
				<title></title>
			</head>
			<body>
				<div id="email-wrap">';
							$message .= '<p>Business Name '.$_POST["business_name"].'</p>';
							$message .= "<p>Address Line : </b>".$_POST["address_line"].' ' .$_POST["address_line2"]."</p>";
							$message .= "<p>City / town: </b>".$_POST["city_town"]."</p>";
							$message .= "<p>state / region: </b>".$_POST["state_region"]."</p>";
							$message .= "<p>Country: </b>".$_POST["business_country_name"]."</p>";
							$message .= "<p>Zip / postal code: </b>".$_POST["zip_code"]."</p><br>";
							$message .= "<p>Sales First Name: </b>".$_POST["sale_first_name"]."</p>";
							$message .= "<p>Sales Last Name: </b>".$_POST["sale_last_name"]."</p>";
							$message .= "<p>Sales Phone Number: </b>".$_POST["sale_phone_number"]."</p>";
							$message .= "<p>Sales Email Address: </b>".$_POST["email_address"]."</p><br>";
							$message .= "<p>Account First Name: </b>".$_POST["account_first_name"]."</p>";
							$message .= "<p>Account Last Name: </b>".$_POST["account_last_name"]."</p>";
							$message .= "<p>Account Phone Number: </b>".$_POST["account_phone_number"]."</p>";
							$message .= "<p>Account Email Address: </b>".$_POST["account_email_address"]."</p>";
							$message .= "<p>Account Address Line: </b>".$_POST["account_address"].' '.$_POST["account_address2"]."</p>";
							$message .= "<p>Account city / town: </b>".$_POST["account_city_town"]."</p>";
							$message .= "<p>Account state / region: </b>".$_POST["account_state_region"]."</p>";
							$message .= "<p>Account Country: </b>".$_POST["account_country_name"]."</p>";
							$message .= "<p>Account zip / postal code: </b>".$_POST["account_zip_code"]."</p>";
							$message .= "<p>CHANNEL NUMBER: </b>".$_POST["channel_number"]."</p>";
							$message .= '<p>EIN NO.: </b>'.$_POST["ein_number"].'</p>';
							$message .= "<p>UPLOADED (PDF): </b><a href='http://alvish.bestwebdevs.com/".$pdf."' download>PDF Download</a></p></div>
									</body>
									</html>"; 
				
					// Send email
					if(mail($to, $subject, $message, $headers)):
						$successMsg = 'Email has sent successfully.';
					else:
						$error  = 'Email sending fail.';
					endif;
					
						
				echo '<script language="javascript">';
				echo 'alert("success")';
				echo '</script>';
			?>
			
			<script type="text/javascript">
window.location = "/wholesale/";

</script> 
<?php

		} 
  
  
}
 ?>
		<section class="wholesale-form">	
		<div class="container">
			<h2> Fill up form to signup for wholesale orders</h2>
			<form action="" method="post" class="wholeSaleForm" enctype="multipart/form-data" >
				<div class="form-group">
					<div class="col-md-12 col-sm-12">
						<label>Business name</label>
						<input type="text" name="business_name"value="" placeholder="Business name" required>
					</div>
				</div>	
				<div class="form-group">
					<div class="col-md-12 col-sm-12">
						<label>Business address</label>
					</div>	
					<div class="col-md-6 col-sm-6">
						<input type="text" name="address_line" value="" placeholder="Address Line 1" required>
					</div>
					<div class="col-md-6 col-sm-6">
						<input type="text" name="address_line2" value="" placeholder="Address Line 2(Optional)" >
					</div>
					<div class="col-md-6 col-sm-6">
						<input type="text" name="city_town" value="" placeholder="city / town" required>
					</div>
					<div class="col-md-6 col-sm-6">
						<input type="text" name="state_region" value="" placeholder="state / region" required>
					</div>
					<div class="col-md-6 col-sm-6">
				<select id="country" name="business_country_name" class="form-control" required>
                <option value="Afghanistan">Afghanistan</option>
                <option value="Åland Islands">Åland Islands</option>
                <option value="Albania">Albania</option>
                <option value="Algeria">Algeria</option>
                <option value="American Samoa">American Samoa</option>
                <option value="Andorra">Andorra</option>
                <option value="Angola">Angola</option>
                <option value="Anguilla">Anguilla</option>
                <option value="Antarctica">Antarctica</option>
                <option value="Antigua and Barbuda">Antigua and Barbuda</option>
                <option value="Argentina">Argentina</option>
                <option value="Armenia">Armenia</option>
                <option value="Aruba">Aruba</option>
                <option value="Australia">Australia</option>
                <option value="Austria">Austria</option>
                <option value="Azerbaijan">Azerbaijan</option>
                <option value="Bahamas">Bahamas</option>
                <option value="Bahrain">Bahrain</option>
                <option value="Bangladesh">Bangladesh</option>
                <option value="Barbados">Barbados</option>
                <option value="Belarus">Belarus</option>
                <option value="Belgium">Belgium</option>
                <option value="Belize">Belize</option>
                <option value="Benin">Benin</option>
                <option value="Bermuda">Bermuda</option>
                <option value="Bhutan">Bhutan</option>
                <option value="Bolivia">Bolivia</option>
                <option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
                <option value="Botswana">Botswana</option>
                <option value="Bouvet Island">Bouvet Island</option>
                <option value="Brazil">Brazil</option>
                <option value="British Indian Ocean Territory">British Indian Ocean Territory</option>
                <option value="Brunei Darussalam">Brunei Darussalam</option>
                <option value="Bulgaria">Bulgaria</option>
                <option value="Burkina Faso">Burkina Faso</option>
                <option value="Burundi">Burundi</option>
                <option value="Cambodia">Cambodia</option>
                <option value="Cameroon">Cameroon</option>
                <option value="Canada">Canada</option>
                <option value="Cape Verde">Cape Verde</option>
                <option value="Cayman Islands">Cayman Islands</option>
                <option value="Central African Republic">Central African Republic</option>
                <option value="Chad">Chad</option>
                <option value="Chile">Chile</option>
                <option value="China">China</option>
                <option value="Christmas Island">Christmas Island</option>
                <option value="Cocos (Keeling) Islands">Cocos (Keeling) Islands</option>
                <option value="Colombia">Colombia</option>
                <option value="Comoros">Comoros</option>
                <option value="Congo">Congo</option>
                <option value="Congo, The Democratic Republic of The">Congo, The Democratic Republic of The</option>
                <option value="Cook Islands">Cook Islands</option>
                <option value="Costa Rica">Costa Rica</option>
                <option value="Cote D'ivoire">Cote D'ivoire</option>
                <option value="Croatia">Croatia</option>
                <option value="Cuba">Cuba</option>
                <option value="Cyprus">Cyprus</option>
                <option value="Czech Republic">Czech Republic</option>
                <option value="Denmark">Denmark</option>
                <option value="Djibouti">Djibouti</option>
                <option value="Dominica">Dominica</option>
                <option value="Dominican Republic">Dominican Republic</option>
                <option value="Ecuador">Ecuador</option>
                <option value="Egypt">Egypt</option>
                <option value="El Salvador">El Salvador</option>
                <option value="Equatorial Guinea">Equatorial Guinea</option>
                <option value="Eritrea">Eritrea</option>
                <option value="Estonia">Estonia</option>
                <option value="Ethiopia">Ethiopia</option>
                <option value="Falkland Islands (Malvinas)">Falkland Islands (Malvinas)</option>
                <option value="Faroe Islands">Faroe Islands</option>
                <option value="Fiji">Fiji</option>
                <option value="Finland">Finland</option>
                <option value="France">France</option>
                <option value="French Guiana">French Guiana</option>
                <option value="French Polynesia">French Polynesia</option>
                <option value="French Southern Territories">French Southern Territories</option>
                <option value="Gabon">Gabon</option>
                <option value="Gambia">Gambia</option>
                <option value="Georgia">Georgia</option>
                <option value="Germany">Germany</option>
                <option value="Ghana">Ghana</option>
                <option value="Gibraltar">Gibraltar</option>
                <option value="Greece">Greece</option>
                <option value="Greenland">Greenland</option>
                <option value="Grenada">Grenada</option>
                <option value="Guadeloupe">Guadeloupe</option>
                <option value="Guam">Guam</option>
                <option value="Guatemala">Guatemala</option>
                <option value="Guernsey">Guernsey</option>
                <option value="Guinea">Guinea</option>
                <option value="Guinea-bissau">Guinea-bissau</option>
                <option value="Guyana">Guyana</option>
                <option value="Haiti">Haiti</option>
                <option value="Heard Island and Mcdonald Islands">Heard Island and Mcdonald Islands</option>
                <option value="Holy See (Vatican City State)">Holy See (Vatican City State)</option>
                <option value="Honduras">Honduras</option>
                <option value="Hong Kong">Hong Kong</option>
                <option value="Hungary">Hungary</option>
                <option value="Iceland">Iceland</option>
                <option value="India">India</option>
                <option value="Indonesia">Indonesia</option>
                <option value="Iran, Islamic Republic of">Iran, Islamic Republic of</option>
                <option value="Iraq">Iraq</option>
                <option value="Ireland">Ireland</option>
                <option value="Isle of Man">Isle of Man</option>
                <option value="Israel">Israel</option>
                <option value="Italy">Italy</option>
                <option value="Jamaica">Jamaica</option>
                <option value="Japan">Japan</option>
                <option value="Jersey">Jersey</option>
                <option value="Jordan">Jordan</option>
                <option value="Kazakhstan">Kazakhstan</option>
                <option value="Kenya">Kenya</option>
                <option value="Kiribati">Kiribati</option>
                <option value="Korea, Democratic People's Republic of">Korea, Democratic People's Republic of</option>
                <option value="Korea, Republic of">Korea, Republic of</option>
                <option value="Kuwait">Kuwait</option>
                <option value="Kyrgyzstan">Kyrgyzstan</option>
                <option value="Lao People's Democratic Republic">Lao People's Democratic Republic</option>
                <option value="Latvia">Latvia</option>
                <option value="Lebanon">Lebanon</option>
                <option value="Lesotho">Lesotho</option>
                <option value="Liberia">Liberia</option>
                <option value="Libyan Arab Jamahiriya">Libyan Arab Jamahiriya</option>
                <option value="Liechtenstein">Liechtenstein</option>
                <option value="Lithuania">Lithuania</option>
                <option value="Luxembourg">Luxembourg</option>
                <option value="Macao">Macao</option>
                <option value="Macedonia, The Former Yugoslav Republic of">Macedonia, The Former Yugoslav Republic of</option>
                <option value="Madagascar">Madagascar</option>
                <option value="Malawi">Malawi</option>
                <option value="Malaysia">Malaysia</option>
                <option value="Maldives">Maldives</option>
                <option value="Mali">Mali</option>
                <option value="Malta">Malta</option>
                <option value="Marshall Islands">Marshall Islands</option>
                <option value="Martinique">Martinique</option>
                <option value="Mauritania">Mauritania</option>
                <option value="Mauritius">Mauritius</option>
                <option value="Mayotte">Mayotte</option>
                <option value="Mexico">Mexico</option>
                <option value="Micronesia, Federated States of">Micronesia, Federated States of</option>
                <option value="Moldova, Republic of">Moldova, Republic of</option>
                <option value="Monaco">Monaco</option>
                <option value="Mongolia">Mongolia</option>
                <option value="Montenegro">Montenegro</option>
                <option value="Montserrat">Montserrat</option>
                <option value="Morocco">Morocco</option>
                <option value="Mozambique">Mozambique</option>
                <option value="Myanmar">Myanmar</option>
                <option value="Namibia">Namibia</option>
                <option value="Nauru">Nauru</option>
                <option value="Nepal">Nepal</option>
                <option value="Netherlands">Netherlands</option>
                <option value="Netherlands Antilles">Netherlands Antilles</option>
                <option value="New Caledonia">New Caledonia</option>
                <option value="New Zealand">New Zealand</option>
                <option value="Nicaragua">Nicaragua</option>
                <option value="Niger">Niger</option>
                <option value="Nigeria">Nigeria</option>
                <option value="Niue">Niue</option>
                <option value="Norfolk Island">Norfolk Island</option>
                <option value="Northern Mariana Islands">Northern Mariana Islands</option>
                <option value="Norway">Norway</option>
                <option value="Oman">Oman</option>
                <option value="Pakistan">Pakistan</option>
                <option value="Palau">Palau</option>
                <option value="Palestinian Territory, Occupied">Palestinian Territory, Occupied</option>
                <option value="Panama">Panama</option>
                <option value="Papua New Guinea">Papua New Guinea</option>
                <option value="Paraguay">Paraguay</option>
                <option value="Peru">Peru</option>
                <option value="Philippines">Philippines</option>
                <option value="Pitcairn">Pitcairn</option>
                <option value="Poland">Poland</option>
                <option value="Portugal">Portugal</option>
                <option value="Puerto Rico">Puerto Rico</option>
                <option value="Qatar">Qatar</option>
                <option value="Reunion">Reunion</option>
                <option value="Romania">Romania</option>
                <option value="Russian Federation">Russian Federation</option>
                <option value="Rwanda">Rwanda</option>
                <option value="Saint Helena">Saint Helena</option>
                <option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option>
                <option value="Saint Lucia">Saint Lucia</option>
                <option value="Saint Pierre and Miquelon">Saint Pierre and Miquelon</option>
                <option value="Saint Vincent and The Grenadines">Saint Vincent and The Grenadines</option>
                <option value="Samoa">Samoa</option>
                <option value="San Marino">San Marino</option>
                <option value="Sao Tome and Principe">Sao Tome and Principe</option>
                <option value="Saudi Arabia">Saudi Arabia</option>
                <option value="Senegal">Senegal</option>
                <option value="Serbia">Serbia</option>
                <option value="Seychelles">Seychelles</option>
                <option value="Sierra Leone">Sierra Leone</option>
                <option value="Singapore">Singapore</option>
                <option value="Slovakia">Slovakia</option>
                <option value="Slovenia">Slovenia</option>
                <option value="Solomon Islands">Solomon Islands</option>
                <option value="Somalia">Somalia</option>
                <option value="South Africa">South Africa</option>
                <option value="South Georgia and The South Sandwich Islands">South Georgia and The South Sandwich Islands</option>
                <option value="Spain">Spain</option>
                <option value="Sri Lanka">Sri Lanka</option>
                <option value="Sudan">Sudan</option>
                <option value="Suriname">Suriname</option>
                <option value="Svalbard and Jan Mayen">Svalbard and Jan Mayen</option>
                <option value="Swaziland">Swaziland</option>
                <option value="Sweden">Sweden</option>
                <option value="Switzerland">Switzerland</option>
                <option value="Syrian Arab Republic">Syrian Arab Republic</option>
                <option value="Taiwan, Province of China">Taiwan, Province of China</option>
                <option value="Tajikistan">Tajikistan</option>
                <option value="Tanzania, United Republic of">Tanzania, United Republic of</option>
                <option value="Thailand">Thailand</option>
                <option value="Timor-leste">Timor-leste</option>
                <option value="Togo">Togo</option>
                <option value="Tokelau">Tokelau</option>
                <option value="Tonga">Tonga</option>
                <option value="Trinidad and Tobago">Trinidad and Tobago</option>
                <option value="Tunisia">Tunisia</option>
                <option value="Turkey">Turkey</option>
                <option value="Turkmenistan">Turkmenistan</option>
                <option value="Turks and Caicos Islands">Turks and Caicos Islands</option>
                <option value="Tuvalu">Tuvalu</option>
                <option value="Uganda">Uganda</option>
                <option value="Ukraine">Ukraine</option>
                <option value="United Arab Emirates">United Arab Emirates</option>
                <option value="United Kingdom">United Kingdom</option>
                <option value="United States">United States</option>
                <option value="United States Minor Outlying Islands">United States Minor Outlying Islands</option>
                <option value="Uruguay">Uruguay</option>
                <option value="Uzbekistan">Uzbekistan</option>
                <option value="Vanuatu">Vanuatu</option>
                <option value="Venezuela">Venezuela</option>
                <option value="Viet Nam">Viet Nam</option>
                <option value="Virgin Islands, British">Virgin Islands, British</option>
                <option value="Virgin Islands, U.S.">Virgin Islands, U.S.</option>
                <option value="Wallis and Futuna">Wallis and Futuna</option>
                <option value="Western Sahara">Western Sahara</option>
                <option value="Yemen">Yemen</option>
                <option value="Zambia">Zambia</option>
                <option value="Zimbabwe">Zimbabwe</option>
            </select>
		
					</div>
					<div class="col-md-6 col-sm-6">
						<input type="text" name="zip_code" value="" placeholder="zip / postal code" required>
					</div>
				</div>	
				<div class="col-md-12 col-sm-12">
					<h4>Sales Contact Details</h4>
				</div>
				<div class="form-group">
					<div class="col-md-6 col-sm-6">
						<label>first name</label>
						<input type="text" value="" name="sale_first_name" placeholder="Enter your first name" required>
					</div>
					<div class="col-md-6 col-sm-6">
						<label>last name</label>
						<input type="text" value="" name="sale_last_name" placeholder="Enter your last name" required>
					</div>
					<div class="col-md-6 col-sm-6">
						<label>Phone number</label>
						<input type="number" value="" min="0" name="sale_phone_number" placeholder="Enter your phone number" required>
					</div>
					<div class="col-md-6 col-sm-6">
						<label>email address</label>
						<input type="email" value="" class="email_address" name="email_address" placeholder="Enter your email address" required>
						<span class="invalidEmail"></span>
					</div>
				</div>
				<div class="col-md-12 col-sm-12">
					<h4>Account Payable Contact Details</h4>
				</div>
				<div class="form-group">
					<div class="col-md-6 col-sm-6">
						<label>first name</label>
						<input type="text" value="" name="account_first_name" placeholder="Enter your first name" required>
					</div>
					<div class="col-md-6 col-sm-6">
						<label>last name</label>
						<input type="text" value="" name="account_last_name"  placeholder="Enter your last name" required>
					</div>
					<div class="col-md-6 col-sm-6">
						<label>Phone number</label>
						<input type="number" value="" min="0" name="account_phone_number" placeholder="Enter your phone number" required>
					</div>
					<div class="col-md-6 col-sm-6">
						<label>email address</label>
						<input type="email" value="" class="account_email_address" name="account_email_address" placeholder="Enter your email address" required>
						<span class="invalidEmail2"></span>
					</div>
				</div>
				<div class="form-group">
					<div class="col-md-12 col-sm-12"><label>address</label></div>
					<div class="col-md-6 col-sm-6">
						<input type="text" value="" name="account_address"placeholder="Address Line 1" required>
					</div>
					<div class="col-md-6 col-sm-6">
						<input type="text" value="" name="account_address2"placeholder="Address Line 2" >
					</div>
					<div class="col-md-6 col-sm-6">
						<input type="text" value="" name="account_city_town" placeholder="city / town" required>
					</div>
					<div class="col-md-6 col-sm-6">
						<input type="text" value="" ame="account_state_region" placeholder="state / region" required>
					</div>
					<div class="col-md-6 col-sm-6">
				 <select id="country" name="account_country_name" class="form-control" required>
                <option value="Afghanistan">Afghanistan</option>
                <option value="Åland Islands">Åland Islands</option>
                <option value="Albania">Albania</option>
                <option value="Algeria">Algeria</option>
                <option value="American Samoa">American Samoa</option>
                <option value="Andorra">Andorra</option>
                <option value="Angola">Angola</option>
                <option value="Anguilla">Anguilla</option>
                <option value="Antarctica">Antarctica</option>
                <option value="Antigua and Barbuda">Antigua and Barbuda</option>
                <option value="Argentina">Argentina</option>
                <option value="Armenia">Armenia</option>
                <option value="Aruba">Aruba</option>
                <option value="Australia">Australia</option>
                <option value="Austria">Austria</option>
                <option value="Azerbaijan">Azerbaijan</option>
                <option value="Bahamas">Bahamas</option>
                <option value="Bahrain">Bahrain</option>
                <option value="Bangladesh">Bangladesh</option>
                <option value="Barbados">Barbados</option>
                <option value="Belarus">Belarus</option>
                <option value="Belgium">Belgium</option>
                <option value="Belize">Belize</option>
                <option value="Benin">Benin</option>
                <option value="Bermuda">Bermuda</option>
                <option value="Bhutan">Bhutan</option>
                <option value="Bolivia">Bolivia</option>
                <option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
                <option value="Botswana">Botswana</option>
                <option value="Bouvet Island">Bouvet Island</option>
                <option value="Brazil">Brazil</option>
                <option value="British Indian Ocean Territory">British Indian Ocean Territory</option>
                <option value="Brunei Darussalam">Brunei Darussalam</option>
                <option value="Bulgaria">Bulgaria</option>
                <option value="Burkina Faso">Burkina Faso</option>
                <option value="Burundi">Burundi</option>
                <option value="Cambodia">Cambodia</option>
                <option value="Cameroon">Cameroon</option>
                <option value="Canada">Canada</option>
                <option value="Cape Verde">Cape Verde</option>
                <option value="Cayman Islands">Cayman Islands</option>
                <option value="Central African Republic">Central African Republic</option>
                <option value="Chad">Chad</option>
                <option value="Chile">Chile</option>
                <option value="China">China</option>
                <option value="Christmas Island">Christmas Island</option>
                <option value="Cocos (Keeling) Islands">Cocos (Keeling) Islands</option>
                <option value="Colombia">Colombia</option>
                <option value="Comoros">Comoros</option>
                <option value="Congo">Congo</option>
                <option value="Congo, The Democratic Republic of The">Congo, The Democratic Republic of The</option>
                <option value="Cook Islands">Cook Islands</option>
                <option value="Costa Rica">Costa Rica</option>
                <option value="Cote D'ivoire">Cote D'ivoire</option>
                <option value="Croatia">Croatia</option>
                <option value="Cuba">Cuba</option>
                <option value="Cyprus">Cyprus</option>
                <option value="Czech Republic">Czech Republic</option>
                <option value="Denmark">Denmark</option>
                <option value="Djibouti">Djibouti</option>
                <option value="Dominica">Dominica</option>
                <option value="Dominican Republic">Dominican Republic</option>
                <option value="Ecuador">Ecuador</option>
                <option value="Egypt">Egypt</option>
                <option value="El Salvador">El Salvador</option>
                <option value="Equatorial Guinea">Equatorial Guinea</option>
                <option value="Eritrea">Eritrea</option>
                <option value="Estonia">Estonia</option>
                <option value="Ethiopia">Ethiopia</option>
                <option value="Falkland Islands (Malvinas)">Falkland Islands (Malvinas)</option>
                <option value="Faroe Islands">Faroe Islands</option>
                <option value="Fiji">Fiji</option>
                <option value="Finland">Finland</option>
                <option value="France">France</option>
                <option value="French Guiana">French Guiana</option>
                <option value="French Polynesia">French Polynesia</option>
                <option value="French Southern Territories">French Southern Territories</option>
                <option value="Gabon">Gabon</option>
                <option value="Gambia">Gambia</option>
                <option value="Georgia">Georgia</option>
                <option value="Germany">Germany</option>
                <option value="Ghana">Ghana</option>
                <option value="Gibraltar">Gibraltar</option>
                <option value="Greece">Greece</option>
                <option value="Greenland">Greenland</option>
                <option value="Grenada">Grenada</option>
                <option value="Guadeloupe">Guadeloupe</option>
                <option value="Guam">Guam</option>
                <option value="Guatemala">Guatemala</option>
                <option value="Guernsey">Guernsey</option>
                <option value="Guinea">Guinea</option>
                <option value="Guinea-bissau">Guinea-bissau</option>
                <option value="Guyana">Guyana</option>
                <option value="Haiti">Haiti</option>
                <option value="Heard Island and Mcdonald Islands">Heard Island and Mcdonald Islands</option>
                <option value="Holy See (Vatican City State)">Holy See (Vatican City State)</option>
                <option value="Honduras">Honduras</option>
                <option value="Hong Kong">Hong Kong</option>
                <option value="Hungary">Hungary</option>
                <option value="Iceland">Iceland</option>
                <option value="India">India</option>
                <option value="Indonesia">Indonesia</option>
                <option value="Iran, Islamic Republic of">Iran, Islamic Republic of</option>
                <option value="Iraq">Iraq</option>
                <option value="Ireland">Ireland</option>
                <option value="Isle of Man">Isle of Man</option>
                <option value="Israel">Israel</option>
                <option value="Italy">Italy</option>
                <option value="Jamaica">Jamaica</option>
                <option value="Japan">Japan</option>
                <option value="Jersey">Jersey</option>
                <option value="Jordan">Jordan</option>
                <option value="Kazakhstan">Kazakhstan</option>
                <option value="Kenya">Kenya</option>
                <option value="Kiribati">Kiribati</option>
                <option value="Korea, Democratic People's Republic of">Korea, Democratic People's Republic of</option>
                <option value="Korea, Republic of">Korea, Republic of</option>
                <option value="Kuwait">Kuwait</option>
                <option value="Kyrgyzstan">Kyrgyzstan</option>
                <option value="Lao People's Democratic Republic">Lao People's Democratic Republic</option>
                <option value="Latvia">Latvia</option>
                <option value="Lebanon">Lebanon</option>
                <option value="Lesotho">Lesotho</option>
                <option value="Liberia">Liberia</option>
                <option value="Libyan Arab Jamahiriya">Libyan Arab Jamahiriya</option>
                <option value="Liechtenstein">Liechtenstein</option>
                <option value="Lithuania">Lithuania</option>
                <option value="Luxembourg">Luxembourg</option>
                <option value="Macao">Macao</option>
                <option value="Macedonia, The Former Yugoslav Republic of">Macedonia, The Former Yugoslav Republic of</option>
                <option value="Madagascar">Madagascar</option>
                <option value="Malawi">Malawi</option>
                <option value="Malaysia">Malaysia</option>
                <option value="Maldives">Maldives</option>
                <option value="Mali">Mali</option>
                <option value="Malta">Malta</option>
                <option value="Marshall Islands">Marshall Islands</option>
                <option value="Martinique">Martinique</option>
                <option value="Mauritania">Mauritania</option>
                <option value="Mauritius">Mauritius</option>
                <option value="Mayotte">Mayotte</option>
                <option value="Mexico">Mexico</option>
                <option value="Micronesia, Federated States of">Micronesia, Federated States of</option>
                <option value="Moldova, Republic of">Moldova, Republic of</option>
                <option value="Monaco">Monaco</option>
                <option value="Mongolia">Mongolia</option>
                <option value="Montenegro">Montenegro</option>
                <option value="Montserrat">Montserrat</option>
                <option value="Morocco">Morocco</option>
                <option value="Mozambique">Mozambique</option>
                <option value="Myanmar">Myanmar</option>
                <option value="Namibia">Namibia</option>
                <option value="Nauru">Nauru</option>
                <option value="Nepal">Nepal</option>
                <option value="Netherlands">Netherlands</option>
                <option value="Netherlands Antilles">Netherlands Antilles</option>
                <option value="New Caledonia">New Caledonia</option>
                <option value="New Zealand">New Zealand</option>
                <option value="Nicaragua">Nicaragua</option>
                <option value="Niger">Niger</option>
                <option value="Nigeria">Nigeria</option>
                <option value="Niue">Niue</option>
                <option value="Norfolk Island">Norfolk Island</option>
                <option value="Northern Mariana Islands">Northern Mariana Islands</option>
                <option value="Norway">Norway</option>
                <option value="Oman">Oman</option>
                <option value="Pakistan">Pakistan</option>
                <option value="Palau">Palau</option>
                <option value="Palestinian Territory, Occupied">Palestinian Territory, Occupied</option>
                <option value="Panama">Panama</option>
                <option value="Papua New Guinea">Papua New Guinea</option>
                <option value="Paraguay">Paraguay</option>
                <option value="Peru">Peru</option>
                <option value="Philippines">Philippines</option>
                <option value="Pitcairn">Pitcairn</option>
                <option value="Poland">Poland</option>
                <option value="Portugal">Portugal</option>
                <option value="Puerto Rico">Puerto Rico</option>
                <option value="Qatar">Qatar</option>
                <option value="Reunion">Reunion</option>
                <option value="Romania">Romania</option>
                <option value="Russian Federation">Russian Federation</option>
                <option value="Rwanda">Rwanda</option>
                <option value="Saint Helena">Saint Helena</option>
                <option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option>
                <option value="Saint Lucia">Saint Lucia</option>
                <option value="Saint Pierre and Miquelon">Saint Pierre and Miquelon</option>
                <option value="Saint Vincent and The Grenadines">Saint Vincent and The Grenadines</option>
                <option value="Samoa">Samoa</option>
                <option value="San Marino">San Marino</option>
                <option value="Sao Tome and Principe">Sao Tome and Principe</option>
                <option value="Saudi Arabia">Saudi Arabia</option>
                <option value="Senegal">Senegal</option>
                <option value="Serbia">Serbia</option>
                <option value="Seychelles">Seychelles</option>
                <option value="Sierra Leone">Sierra Leone</option>
                <option value="Singapore">Singapore</option>
                <option value="Slovakia">Slovakia</option>
                <option value="Slovenia">Slovenia</option>
                <option value="Solomon Islands">Solomon Islands</option>
                <option value="Somalia">Somalia</option>
                <option value="South Africa">South Africa</option>
                <option value="South Georgia and The South Sandwich Islands">South Georgia and The South Sandwich Islands</option>
                <option value="Spain">Spain</option>
                <option value="Sri Lanka">Sri Lanka</option>
                <option value="Sudan">Sudan</option>
                <option value="Suriname">Suriname</option>
                <option value="Svalbard and Jan Mayen">Svalbard and Jan Mayen</option>
                <option value="Swaziland">Swaziland</option>
                <option value="Sweden">Sweden</option>
                <option value="Switzerland">Switzerland</option>
                <option value="Syrian Arab Republic">Syrian Arab Republic</option>
                <option value="Taiwan, Province of China">Taiwan, Province of China</option>
                <option value="Tajikistan">Tajikistan</option>
                <option value="Tanzania, United Republic of">Tanzania, United Republic of</option>
                <option value="Thailand">Thailand</option>
                <option value="Timor-leste">Timor-leste</option>
                <option value="Togo">Togo</option>
                <option value="Tokelau">Tokelau</option>
                <option value="Tonga">Tonga</option>
                <option value="Trinidad and Tobago">Trinidad and Tobago</option>
                <option value="Tunisia">Tunisia</option>
                <option value="Turkey">Turkey</option>
                <option value="Turkmenistan">Turkmenistan</option>
                <option value="Turks and Caicos Islands">Turks and Caicos Islands</option>
                <option value="Tuvalu">Tuvalu</option>
                <option value="Uganda">Uganda</option>
                <option value="Ukraine">Ukraine</option>
                <option value="United Arab Emirates">United Arab Emirates</option>
                <option value="United Kingdom">United Kingdom</option>
                <option value="United States">United States</option>
                <option value="United States Minor Outlying Islands">United States Minor Outlying Islands</option>
                <option value="Uruguay">Uruguay</option>
                <option value="Uzbekistan">Uzbekistan</option>
                <option value="Vanuatu">Vanuatu</option>
                <option value="Venezuela">Venezuela</option>
                <option value="Viet Nam">Viet Nam</option>
                <option value="Virgin Islands, British">Virgin Islands, British</option>
                <option value="Virgin Islands, U.S.">Virgin Islands, U.S.</option>
                <option value="Wallis and Futuna">Wallis and Futuna</option>
                <option value="Western Sahara">Western Sahara</option>
                <option value="Yemen">Yemen</option>
                <option value="Zambia">Zambia</option>
                <option value="Zimbabwe">Zimbabwe</option>
            </select>
						
					</div>
					<div class="col-md-6 col-sm-6">
						<input type="text" value="" name="account_zip_code" placeholder="zip / postal code" required>
					</div>
				</div>
				
					<div class="form-group">
						<div class="col-md-12 col-sm-12">
							<label>ASI / PPAI / Other Distributor channel no.</label>
						</div>	
						<div class="col-md-12 col-sm-12">
							<input type="text" value="" name="channel_number" placeholder="CHANNEL NUMBER" required>
						</div>
						<div class="col-md-6 col-sm-6">
							<label>EIN no.</label>	
							<input type="text" name="ein_number" placeholder="EIN no." required>
						</div>
						<div class="col-md-6 col-sm-6">
							<label>Upload (Pdf)</label>
							<div class="upload-btn-wrapper">
							  <button class="btn"> <i class="las la-paperclip"></i>Upload (PDF)</button>
							 	<input type="file" name="fileUpload" id="channel_myfile"  accept="application/pdf"/>
							</div>
						</div>
						
						<input type="hidden" name="post_id" id="post_id" value="<?php echo get_the_ID();?>" />
		
	
	

						
					</div>
					<div class="col-md-12 col-sm-12">
						<button type="submit" name="submit" class="wholesale-submit">submit</button>
					</div>
				
			</form>
		</div>
	</section>
	
<script>
/*       $(".wholeSaleForm").submit(function( event ) {
        var business_name = $("input[name='business_name']").val();
        var address_line = $("input[name='address_line']").val();
        var city_town = $("input[name='city_town']").val();
        var state_region = $("input[name='state_region']").val();
        var business_country_name = $("input[name='business_country_name']").val();
        var zip_code = $("input[name='zip_code']").val();
        var sale_first_name = $("input[name='sale_first_name']").val();
        var sale_last_name = $("input[name='sale_last_name']").val();
        var sale_phone_number = $("input[name='sale_phone_number']").val();
        var email_address = $("input[name='email_address']").val();
        var account_first_name = $("input[name='account_first_name']").val();
        var account_last_name = $("input[name='account_last_name']").val();
        var account_phone_number = $("input[name='account_phone_number']").val();
        var account_email_address = $("input[name='account_email_address']").val();
        var account_address = $("input[name='account_address']").val();
        var account_city_town = $("input[name='account_city_town']").val();
        var account_state_region = $("input[name='account_state_region']").val();
        var account_zip_code = $("input[name='account_zip_code']").val();
        var channel_number = $("input[name='channel_number']").val();
        var ein_number = $("input[name='ein_number']").val();

        if(business_name.trim() == "" && address_line.trim() == "" && city_town.trim() == "" && state_region.trim() == "" && business_country_name.trim() == "" && zip_code.trim() == "" && sale_first_name.trim() == "" && sale_last_name.trim() == "" && sale_phone_number.trim() == "" && email_address.trim() == "" && account_first_name.trim() == "" && account_last_name.trim() == "" && account_phone_number.trim() == "" && account_email_address.trim() == "" && account_address.trim() == "" && account_city_town.trim() == "" && account_state_region.trim() == "" && account_zip_code.trim() == "" && channel_number.trim() == ""  && ein_number.trim() == ""){
        alert("Please Fill The Remaining Fields!");
          return false;
        }
        if(FirstName.trim() == ""){
          $(".inValidClass").show();
          return false;
        }else{
          $(".inValidClass").hide();
        }
        if(LastName.trim() == ""){
          $("#LastName").addClass("focus-visible");
          $(".inValidClass2").show();
          return false;
        }else{
          $(".inValidClass2").hide();

        }
      }); */

</script>
	
<?php
get_footer();
?>