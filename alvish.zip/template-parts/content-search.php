<?php
/**
 * The template part for displaying results in search pages
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */
 
 if(get_post_type() == "product"){
 	global $product;
				$_product = wc_get_product( $product->get_the_ID());	
?>

	<li>
					
					<figcaption>
						<h3><a href="<?php echo get_permalink();?>"><?php the_title();?></a></h3>
								
									<div class="deail-price">
							<?php echo	$price_html = $product->get_price_html();?>
						</div>
					<!--		<div class="deail-price">
							<span class="discount"></span>
							<span><?php echo get_woocommerce_currency_symbol();?><?php echo $product->get_price();?></span>
							</div>-->

					</figcaption>
					
				</li>
				<?php
 }else{
	 

 }
 ?>
				


