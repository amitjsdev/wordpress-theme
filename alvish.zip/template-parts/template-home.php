<?php

/*
Template Name: Home-page
 */
 
 get_header();
  global $redux_demo;
 ?>
	<div class="for-mobile">
		<ul id="cata-slide">
			<li class="item"><a href="/product-category/men/"><img src="http://alvish.bestwebdevs.com/wp-content/uploads/2020/03/men.png"></a></li>
			<li class="item"><a href="/product-category/men/"><img src="http://alvish.bestwebdevs.com/wp-content/uploads/2020/03/WOMEN.png"></a></li>
			<li class="item"><a href="/product-category/men/"><img src="http://alvish.bestwebdevs.com/wp-content/uploads/2020/03/KIDS.png"></a></li>
		</ul>
	</div>
	<section class="silder-section">
		<div class="container">
			<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
				  <!-- Indicators -->
				  <ol class="carousel-indicators">
				  <?php
				  if( have_rows('home_slider') ):
				$ab=0;
				$a=1;
					// loop through the rows of data
					while ( have_rows('home_slider') ) : the_row();
					?>
					<li data-target="#carousel-example-generic" data-slide-to="<?php echo $ab;?>" class="<?php if($a == 1){ echo "active"; }?>"><span><?php echo $a;?></span></li>
					<?php
						$ab++;
						$a++;
					endwhile;
					endif;
					?>
					
				  </ol>

				  <!-- Wrapper for slides -->
				  <div class="carousel-inner" role="listbox">
				  
				  	<?php
	$b=1;

	if( have_rows('home_slider') ):
				
					// loop through the rows of data
					while ( have_rows('home_slider') ) : the_row();
					?>
					<div class="item <?php if($b == 1){ echo "active"; }?>">
					  <img src="<?php the_sub_field('slider_image');?>" alt="...">
					  <div class="carousel-caption">
						<img src="<?php the_sub_field('slider_logo');?>">
							<?php the_sub_field('slider_content');?>
						<a href="<?php the_sub_field('button_url');?>"><?php the_sub_field('button_title');?></a>
					  </div>
					</div>
					<?php
					$b++;
					endwhile;
					endif;
					?>
					
				  </div>
		
				</div>
		</div>
	</section>
	
	<section class="discount">
		<div class="container">
			<h6><i class="las la-tags"></i>  <?php echo get_field("discount_banner");?></h6>
		</div>
	</section>
	<section class="catageory">
		<div class="container">
			<ul id="cateogory-silder">
			<?php
				  if( have_rows('hot_deals_section') ):
				$c=1;
					// loop through the rows of data
					while ( have_rows('hot_deals_section') ) : the_row();
					?>
				<li class="item" style=background:url('<?php //the_sub_field('hot_deal_img');?>')>
					<figure>
						<a href="<?php the_sub_field('button_url');?>">
						<img src="<?php the_sub_field('hot_deal_img');?>">
						</a>
					</figure>
					
					<!--<div class="conaent-sec">
						<h6><a href="<?php the_sub_field('button_url');?>"><?php the_sub_field('deal_title');?></a></h6>
						<h3><a href="<?php the_sub_field('button_url');?>"><?php the_sub_field('off_title');?></a></h3>
						<a href="<?php the_sub_field('button_url');?>" class="shop-now"><?php the_sub_field('button_title');?></a>
					</div>	-->
					<!--<a href="<?php the_sub_field('button_url');?>" class="shop-all"></a>-->
				</li>
			<?php
			$c++;
			endwhile;
			endif;
			?>
			</ul>
		</div>
	</section>
	
	<section class="best-deail-sec">
		<div class="container">
		<h3><?php echo get_field("best_deal_title");?></h3>
		<p><?php echo get_field("best_deal_content");?></p>
			<div class="row">	
				<div class="col-sm-3 sol-md-3">
					<div class="deail-off-sec">
						<div class="content-inner">
						<?php echo get_field("best_deal_off_content");?>
							<ul id="timer">
							</ul>
							<a class="viewtimerBtn hidden-lg hidden-md hidden-sm" href="<?php echo get_site_url();?>/shop/"><span>View All</span></a>
						</div>	
					</div>
				</div>
				<div class="col-sm-9 sol-md-9">
					<div id="deail-silder">
					  					<?php
				$args = array(
							'post_type' => 'product',
				'order'    =>  'DESC',
				'posts_per_page' =>8,
				'tax_query' => array(
					array(
						'taxonomy'  => 'product_cat',
						'field'     => 'id',
						'terms'     => 45
					),
				),
				
			);
				$loop = new WP_Query( $args );
				while ( $loop->have_posts() ) : $loop->the_post();
					global $product;
				$_product = wc_get_product( $product->get_id());			
				 $product->get_id();
				 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $product->get_id() ), 'single-post-thumbnail' );
				?>
						<div class="item">
							<figure><a href="<?php echo get_permalink( $product->get_id() );?>"><img src="<?php echo $image[0];?>"></a></figure>
							<a href="<?php echo get_permalink( $product->get_id() );?>"><figcaption>
								<h4 class="wooTitle"><?php echo get_the_title();?></h4>
								<div class="deail-price">
<?php echo	$price_html = $product->get_price_html();?>
</div>

					<!--<div class="deail-price">
					<span class="discount"><?php
					if( $_product->is_type( 'simple' ) ) {
					echo $product->regular_price;
					}
					else{
					$product_variations = $product->get_available_variations();
					$variation_product_id = $product_variations [0]['variation_id'];
					$variation_product = new WC_Product_Variation( $variation_product_id );
					echo get_woocommerce_currency_symbol().$variation_product ->regular_price;
					}
					?></span>
					<span><?php echo get_woocommerce_currency_symbol();?><?php echo $_product->get_price();?></span>
					</div>-->
							</figcaption></a>
						</div>
						
				<?php	  
						
			endwhile;
			wp_reset_query();?>	

					</div>
				</div>
			</div>	
		</div>
	</section>
	
	<section class="catageory-sec hidden-xs">
		<div class="container">
			<h3><?php echo get_field("categories_title");?></h3>
			<p><?php echo get_field("categories_sub_title");?></p>
			<div class="col-md-6 col-sm-6">
				<figure>
					<a class="" href="<?php echo get_field("category_first_url");?>">
					<img src="http://alvish.bestwebdevs.com/wp-content/uploads/2020/03/cata-new1.png"></a>
				</figure>
				<!--<div class="outer-sec left-main" style="background:url(<?php echo get_field("category_first_image");?>)">
					<div class="cata-inner">
						<?php echo get_field("category_first_content");?>
						<a href="<?php echo get_field("category_first_url");?>"> shop now </a>
					</div>
					<a class="shop-all" href="<?php echo get_field("category_first_url");?>"> </a>
				</div>-->
			</div>
			<div class="col-md-6 col-sm-6">
				<div class="row">
					<div class="col-md-12 col-sm-12">
						<figure class="second-cate">
						<a class="" href="<?php echo get_field("category_second_content");?>">
							<img src="http://alvish.bestwebdevs.com/wp-content/uploads/2020/03/cata-new2.png"></a>
						</figure>
						<!--<div class="outer-sec second-sec"   style="background:url(<?php echo get_field("category_second_image");?>)">
							<div class="cata-inner">
									<?php echo get_field("category_second_content");?>
								<a href="<?php echo get_field("category_second_url");?>"> shop now </a>
							</div>
							<a class="shop-all" href="<?php echo get_field("category_second_url");?>"> </a>
						</div>-->
					</div>
					<div class="col-md-6 col-sm-6">
						<figure>
							<a class="" href="<?php echo get_field("category_third_image");?>">
							<img src="http://alvish.bestwebdevs.com/wp-content/uploads/2020/03/cata-new3.png"></a>
						</figure>
						<!--<div class="outer-sec"  style="background:url(<?php echo get_field("category_third_image");?>)">
							<div class="cata-inner">
								<?php echo get_field("category_third_content");?>
								<a href="<?php echo get_field("category_third_url");?>"> shop now </a>
							</div>
							<a class="shop-all" href="<?php echo get_field("category_second_url");?>"> </a>
						</div>-->
					</div>
					<div class="col-md-6 col-sm-6">
						<figure>
							<a class="" href="<?php echo get_field("category_fourth_image");?>">
							<img src="http://alvish.bestwebdevs.com/wp-content/uploads/2020/03/cata-new4.png"></a>
						</figure>
						<!--<div class="outer-sec"  style="background:url(<?php echo get_field("category_fourth_image");?>)">
							<div class="cata-inner">
								<?php echo get_field("category_fourth_content");?>
								<a href="<?php echo get_field("category_fourth_url");?>"> shop now </a>
							</div>
							<a class="shop-all" href="<?php echo get_field("category_fourth_url");?>">  </a>
						</div>-->
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="catageory-sec hidden-md hidden-sm hidden-lg">
	<div class="innr">
			<h3><?php echo get_field("categories_title");?></h3>
			<p><?php echo get_field("categories_sub_title");?></p>
		<div id="cata-mobile">

			<div class="item">
				<figure>
					<a class="" href="<?php echo get_field("category_first_url");?>">
					<img src="http://alvish.bestwebdevs.com/wp-content/uploads/2020/03/cata-new-mobile.png"></a>
				</figure>
			</div>
			<div class="item">
				<figure>
				<a class="" href="<?php echo get_field("category_second_content");?>">
					<img src="http://alvish.bestwebdevs.com/wp-content/uploads/2020/03/cata-new2-mobile.png"></a>
				</figure>
			</div>
			<div class="item">
				<figure>
					<a class="" href="<?php echo get_field("category_third_image");?>">
					<img src="http://alvish.bestwebdevs.com/wp-content/uploads/2020/03/cata-new3.png"></a>
				</figure>
			</div>
			<div class="item">
				<figure>
					<a class="" href="<?php echo get_field("category_fourth_image");?>">
					<img src="http://alvish.bestwebdevs.com/wp-content/uploads/2020/03/cata-new4.png"></a>
				</figure>
			</div>
		</div>
		</div>
	</section>

	<section class="our-prodcut">
		<div class="container">
			<h3><?php echo get_field("our_product_title");?></h3>
			<p><?php echo get_field("our_product_content");?></p>
			
			<ul id="deail-silder2">
			  					<?php
				$args = array(
					'post_type' => 'product',
					'orderby'   => 'title',
					'order'    =>  'DESC',
					'posts_per_page' =>8
				);

				$loop = new WP_Query( $args );
				while ( $loop->have_posts() ) : $loop->the_post();
					global $product;
				$_product = wc_get_product( $product->get_id());			
				 $product->get_id();
				 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $product->get_id() ), 'single-post-thumbnail' );
				?>
				
				<li class="item">
					<a href="<?php echo get_permalink( $product->get_id() );?>"><figure>
						<img src="<?php echo $image[0];?>">
					</figure>
					<figcaption>
						<h4 class="wooTitle"><?php echo get_the_title();?></h4>
						<div class="deail-price">
<?php echo	$price_html = $product->get_price_html();?>
</div>

					<!--	<div class="deail-price">
								<span class="discount"><?php 
								  	if( $_product->is_type( 'simple' ) ) {
						echo $product->regular_price;
					}
				else{
		$product_variations = $product->get_available_variations();
		$variation_product_id = $product_variations [0]['variation_id'];
		$variation_product = new WC_Product_Variation( $variation_product_id );
		echo get_woocommerce_currency_symbol().$variation_product ->regular_price;
					}
					?></span>
								<span><?php echo get_woocommerce_currency_symbol();?><?php echo $_product->get_price();?></span>
							</div>-->
					</figure>
					</a>
				</li>
			
				<?php	  
						
			endwhile;
			wp_reset_query();?>
				<li class="item viewBtn"><div class="btn-center"><a class="viewAllBtn hidden-lg hidden-md hidden-sm" href="<?php echo get_site_url();?>/shop/"><span>View All</span></a></div></li>
			</ul>
			
	</section>
	
	<section class="collection-sec hidden-xs">
		<div class="container">
			<div class="row1">
				<div class="col-xs-12 col-lg-7 col-md-7 col-sm-7">
					
						<figure>
							<a href="<?php echo get_field("collection_sale_first_url");?>">
								<img src="<?php echo get_field("collection_sale_first_image");?>">
							</a>
						</figure>
			
							
				
				</div>
				<div class="col-xs-12  col-md-5 col-sm-5 col-lg-5">
					<div class="row">
						<div class="col-md-12 col-sm-12">
							
									
							<figure class="second-arrival">	
								<a href="<?php echo get_field("collection_sale_second_url");?>"><img src="<?php echo get_field("collection_sale_second_image");?>"></a>
							</figure>
					
								
						</div>
						<div class="col-xs-12 col-md-12 col-sm-12">
				
												
								<figure>
								<a href="<?php echo get_field("collection_sale_third_url");?>">
									<img src="<?php echo get_field("collection_sale_third_image");?>">	 </a>
								</figure>
					
							
							
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="collection-sec hidden-lg hidden-md hidden-sm">
		<div class="container">
			<div id="collect-silder">
				<div class="item">
					<figure>
							<a href="<?php echo get_field("collection_sale_first_url");?>">
								<img src="http://alvish.bestwebdevs.com/wp-content/uploads/2020/03/arrival-mobile.png">
							</a>
					</figure>
				</div>
				<div class="item">
						<figure class="second-arrival">	<a href="<?php echo get_field("collection_sale_second_url");?>"><img src="<?php echo get_field("collection_sale_second_image");?>"></a></figure>	
				</div>
				<div class="item">
					<figure>
								<a href="<?php echo get_field("collection_sale_third_url");?>">
									<img src="<?php echo get_field("collection_sale_third_image");?>">	 </a>
								</figure>	
				</div>
			
			</div>
		</div>
	</section>
	<section class="style-sec">
		<div class="container">
			<h3><?php echo get_cat_name(18);?></h3>
			<p><?php echo category_description(18);?></p>
			<ul id="deail-silder6">
			 <?php
$args = array( 'posts_per_page' => 4, 'offset'=> 0, 'category' => 18 );
$myposts = get_posts( $args );
foreach ( $myposts as $post ) : setup_postdata( $post ); ?>
		<li class="item">
					 <a href="<?php the_permalink();  ?>" ><figure><img src="<?php echo get_the_post_thumbnail_url(); ?>"></figure>
					<figcaption>
						<h4><?php the_title(); ?></h4>
						<p><?php echo the_content(); ?></p>
					</figcaption></a>
				</li>
<?php endforeach; 
wp_reset_postdata();?>

			</ul>
		</div>
	</section>
	
	<section class="shipping-sec">
		<div class="container">
			<ul id="deail-silder7">
						<?php
				  if( have_rows('shipping__section') ):
				$c=1;
					// loop through the rows of data
					while ( have_rows('shipping__section') ) : the_row();
					?>
					
				<li class="item">
					<figure><img src="<?php the_sub_field('logo');?>"></figure>
					<figcaption>
						<h3><?php the_sub_field('title');?></h3>
						<p> <?php the_sub_field('content');?> </p>
					</figcaption>
				</li>
				
					<?php
						
					endwhile;
					endif;
					?>
								</ul>
		</div>
	</section>
	<section class="nesletter-sec">
		<div class="container">
			<div class="col-md-6 col-sm-6">
				<h3>Join Our Mailing List</h3>
				<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
			</div>
			<div class="col-md-6 col-sm-6">
			<?php echo do_shortcode("[email-subscribers-form id='1']");?>
			</div>
		</div>
	</section>
	
	
	
<?php
get_footer();
?>