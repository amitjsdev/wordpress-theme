
<?php

$args = array(
    'posts_per_page'   => -1,
    'orderby'          => 'title',
    'order'            => 'asc',
    'post_type'        => 'shop_coupon',
    'post_status'      => 'publish',
);
    
$coupons = get_posts( $args );

?>


<div class="coupnsDIv">
<ul class="coupnsUl">
<?php 
foreach ( $coupons as $coupon ) {
	
	/* echo "<pre>";
	print_r($coupon);
	echo "</pre>" */
	?>
<li>
	<div class="offer-sec">
		<?php echo  get_post_meta( $coupon->ID, 'coupon_amount', true );?>%<span>off</span>
	</div>
	<div class="order-minimun">
	<p><?php echo $coupon->post_excerpt;?></p>
		<p>Code:<span><?php echo $coupon->post_name;?></span>
	</div>
	<div class="expery-date">
		<h6>Expiry: <b><?php

		   $expdate = get_post_meta($coupon->ID, 'date_expires', true);
	echo date('F d, Y', $expdate);  
		
		?></b> <a href="#" class="hide">Hide</a> </h6>
	</div>
	<!--<span class="couponTitle"><?php echo $coupon->post_name;?></span>
	<span class="couponDescription"><?php echo $coupon->post_excerpt;?></span>-->
</li>
<?php
}
?>

</ul>
</div>