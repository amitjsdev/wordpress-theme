<?php
/**
 * The template for displaying the header
 *
 * Displays all of the head element and everything up until the "site-content" div.
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

   
    global $post;

    if ( empty( $_COOKIE['woocommerce_recently_viewed'] ) )
        $viewed_products = array();
    else
        $viewed_products = (array) explode( '-',$_COOKIE['woocommerce_recently_viewed'] );

    if ( ! in_array( $post->ID, $viewed_products ) ) {
        $viewed_products[] = $post->ID;
    }

    if ( sizeof( $viewed_products ) > 15 ) {
        array_shift( $viewed_products );
    }

    // Store for session only
    wc_setcookie( 'woocommerce_recently_viewed', implode( '-',$viewed_products ) );
//setcookie("woocommerce_recently_viewed", $viewed_products); 

    // Store for session only
    //setcookie( 'woocommerce_recently_viewed', implode( '|', $viewed_products ) );
			/*   $cookie_name = "woocommerce_recently_viewed_item";
	 setcookie($cookie_name, implode( '|', $viewed_products ), time() + (86400 * 365), "/");
	 
	echo $_COOKIE["woocommerce_recently_viewed_item"];
	print_r($_COOKIE["woocommerce_recently_viewed_item"]); */
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="icon" href="<?php echo get_site_url();?>/wp-content/uploads/2020/02/favicon.png" sizes="32x32" />
<link rel="icon" href="<?php echo get_site_url();?>/wp-content/uploads/2020/02/favicon.png" sizes="192x192" />
<link rel="apple-touch-icon-precomposed" href="<?php echo get_site_url();?>/wp-content/uploads/2020/02/favicon.png" />
<meta name="msapplication-TileImage" content="<?php echo get_site_url();?>/wp-content/uploads/2020/02/favicon.png" />
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title><?php the_title();?></title>
		<link href="<?php echo get_template_directory_uri();?>/css/bootstrap.min.css" rel="stylesheet">
		<link href="<?php echo get_template_directory_uri();?>/css/style.css?<?php echo rand(1,1000); ?>" rel="stylesheet">
			<link href="<?php echo get_template_directory_uri();?>/style.css?<?php echo rand(1,1000); ?>" rel="stylesheet">
	   <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/css/docs.theme.min.css?66">
	  <!-- Owl Stylesheets -->
	  <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/css/owl.carousel.min.css">
      <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/css/owl.theme.default.min.css">
	  <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/css/lineawsome/css/line-awesome.min.css">
	  <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
	  <?php if(is_product()){
		  ?>
	  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.css'>
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.css'>

<?php
	  }else{
	  ?>
	  <style>
	  .woocommerce-notices-wrapper {
    display: none;
}
	  </style>
	  <?php
}
	  wp_head();
	  global $woocommerce;
   global $redux_demo;
   
   ?>
  </head>
  
    <?php
if (is_page('register')){ 

  ?>
   <body <?php   echo body_class( 'registerpage' );  ?>>
   <?php
   }else{
	   ?>

  <?php
  if (is_account_page()){ 
 if ( is_user_logged_in() ) {


	
  ?>
  
   <body <?php   echo body_class( 'is-woocommerce-account' );  ?>>
   
   <?php
    }  else{
		?>
		   <body <?php   echo body_class();  ?>>
		<?php
	}
   }else{
	   ?>
  <body>
  <?php
  }
  ?>
  
   
  <?php
  }
  ?>
	<!---header section start---->
		<header class="clearHeader">
			<div class="container">
				<nav class="navbar navbar-default">
					<!-- Brand and toggle get grouped for better mobile display -->
					
					<div class="navbar-header">
					
					  <button type="button" class="topNavToggle navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					  </button>
					  <div class="menu-mobile hidden-sm hidden-md hidden-lg">
						<ul class="nav navbar-nav navbar-right">
							<li class="sec-sec"><i class="las la-search mobileSrchICon"></i></li>
							<form role="search" method="get"  action="<?php echo esc_url( home_url( '/' ) ); ?>" class="navbar-form navbar-left  mobileSrch" style="display:none;">
							<span class="closeSrch">X</span>
								<div class="form-group">
								  <input type="text" class="form-control"  name="s" placeholder="Search for products, brands and more">
								<button type="submit" class="btn btn-default"><i class="las la-search"></i></button>
								</div>
							  </form>
						<li><a href="/my-account/"><i class="las la-user"></i><br></a></li>
							<?php $wishlist_count = YITH_WCWL()->count_products(); ?>
						<li><a href="/wishlist/"><i class="fa fa-heart-o" aria-hidden="true"></i><br> <span class="your-counter-selector"><?php echo $wishlist_count; ?></span></a></li>
						<li><a href="/cart"><i class="las la-shopping-bag"></i><br> <span><?php echo $woocommerce->cart->cart_contents_count;?></span></a></li>	
						</ul>
					</div>
					  <a class="navbar-brand" href="<?php echo get_site_url();?>">
					        <img src="<?php echo $redux_demo['opt-header-logo']['url'];?>"></a>
					</div>

					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<?php //wp_nav_menu(array('menu'=>'main-menu','menu_class'=>'nav navbar-nav'));?>
					
					<?php wp_nav_menu( array( 'theme_location' => 'primary','menu_class'=>'nav navbar-nav' ) ); ?>
					
					  <form role="search" method="get"  action="<?php echo esc_url( home_url( '/' ) ); ?>" class="navbar-form navbar-left hidden-xs">
						<div class="form-group">
						  <input type="text" class="form-control"  name="s" placeholder="Search for products, brands and more">
						<button type="submit" class="btn btn-default"><i class="las la-search"></i></button>
						</div>
					  </form>
					  <ul class="nav navbar-nav navbar-right hidden-xs">
						<li class="call-sec"><a href="tel:<?php echo $redux_demo['opt-contactNo'];?>"><i class="las la-phone"></i><?php echo $redux_demo['opt-contactNo'];?></a></li>
						<li><a href="/my-account/"><i class="las la-user"></i><br>Profile</a></li>
							<?php $wishlist_count = YITH_WCWL()->count_products(); ?>
						<li><a href="/wishlist/"><i class="fa fa-heart-o" aria-hidden="true"></i><br>Wishlist <span class="your-counter-selector"><?php echo $wishlist_count; ?></span></a></li>
						<li><a href="/cart"><i class="las la-shopping-bag"></i><br>Bag<span><?php echo $woocommerce->cart->cart_contents_count;?></span></a></li>	
					  </ul>
					</div><!-- /.navbar-collapse -->
				</nav>
			</div><!-- /.container-fluid -->
		<section class="tax-sec">
			<div class="container">
			<h2><i class="las la-tag"></i> <?php echo get_field("tax_title",12);?></h2>
			</div>
			</section>
		</header>
			
	

	<!--header section end--->

		<script>
			var mobileBtnPosition = '';
	jQuery(window).load(function(){
		mobileBtnPosition = $('.add-cart-mobile').offset();
		mobileBtnPosition = mobileBtnPosition.top;
		console.log(mobileBtnPosition)
		jQuery('.btn-for-mobile').addClass('cart-btn-fixed');
	})
	jQuery(window).scroll(function() {
		var scroll = $(window).scrollTop();
		
		if (scroll >= 100) {
			jQuery(".clearHeader").addClass("darkHeader");
		}else{
			jQuery(".clearHeader").removeClass("darkHeader");
		}
		
		if(scroll >= mobileBtnPosition){
			jQuery('.btn-for-mobile').removeClass('cart-btn-fixed')
		}else{
			jQuery('.btn-for-mobile').addClass('cart-btn-fixed')
		}
		
	});
		</script>	
